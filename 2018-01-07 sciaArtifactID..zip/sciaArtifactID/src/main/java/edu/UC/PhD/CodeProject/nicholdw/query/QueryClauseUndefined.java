package edu.UC.PhD.CodeProject.nicholdw.query;

public class QueryClauseUndefined extends QueryClause {
	public QueryClauseUndefined() {
		super ("Undefined");
	}
}
