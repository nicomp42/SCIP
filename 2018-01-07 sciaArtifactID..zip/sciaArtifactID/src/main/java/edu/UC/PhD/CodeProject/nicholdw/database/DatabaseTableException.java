package edu.UC.PhD.CodeProject.nicholdw.database;

public class DatabaseTableException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DatabaseTableException(String message) {
		super(message);
	}
}
