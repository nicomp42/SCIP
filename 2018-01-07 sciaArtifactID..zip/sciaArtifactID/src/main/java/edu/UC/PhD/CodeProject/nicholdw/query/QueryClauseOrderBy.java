package edu.UC.PhD.CodeProject.nicholdw.query;

public class QueryClauseOrderBy extends QueryClause {
	public QueryClauseOrderBy() {super ("Order By");}
}
