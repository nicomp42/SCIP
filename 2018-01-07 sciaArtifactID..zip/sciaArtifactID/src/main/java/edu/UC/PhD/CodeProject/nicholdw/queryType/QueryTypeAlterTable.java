package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeAlterTable extends QueryTypeAlter {
	public QueryTypeAlterTable() {
		super("Alter Table");
	}
}
