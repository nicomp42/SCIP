package edu.UC.PhD.CodeProject.nicholdw.query;

public class QueryClauseWhere extends QueryClause {

	public QueryClauseWhere() {super ("Where");}

}
