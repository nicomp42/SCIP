package edu.UC.PhD.CodeProject.nicholdw.query;

public class QueryClauseUnknown extends QueryClause {
	public QueryClauseUnknown() {
		super("UNKNOWN");
	}
}
