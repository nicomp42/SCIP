package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeDropTable extends QueryTypeDrop {
	public QueryTypeDropTable() {
		super("DROP TABLE");
	}
}
