package edu.UC.PhD.CodeProject.nicholdw.exception;

public class DataTypeException extends Exception {

	private static final long serialVersionUID = 1L;

	public DataTypeException(String message) {
		super(message);
	}
}
