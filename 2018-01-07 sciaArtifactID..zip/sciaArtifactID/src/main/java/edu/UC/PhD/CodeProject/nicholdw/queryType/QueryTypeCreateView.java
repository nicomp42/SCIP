package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeCreateView extends QueryTypeCreate {
	public QueryTypeCreateView() {
		super("CREATE VIEW");
	}
}
