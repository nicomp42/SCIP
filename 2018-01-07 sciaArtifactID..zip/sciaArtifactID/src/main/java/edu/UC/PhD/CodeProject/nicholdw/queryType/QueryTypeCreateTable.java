package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeCreateTable extends QueryTypeCreate {
	public QueryTypeCreateTable() {
		super("CREATE TABLE");
	}
}
