package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeUpdate extends QueryType {
	public QueryTypeUpdate() {
		super("Update");
	}

}
