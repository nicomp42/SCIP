package edu.UC.PhD.CodeProject.nicholdw.query;

public class QuerySchema {
	private String schemaName;

	public QuerySchema(String schemaName) {
		this.schemaName = schemaName;
	}
	public String getSchemaName() {
		return schemaName;
	}
	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}
}
