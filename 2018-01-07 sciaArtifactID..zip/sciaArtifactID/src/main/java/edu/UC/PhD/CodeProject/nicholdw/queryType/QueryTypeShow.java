package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeShow extends QueryType {
	public QueryTypeShow() {
		super("Show");
	}
}
