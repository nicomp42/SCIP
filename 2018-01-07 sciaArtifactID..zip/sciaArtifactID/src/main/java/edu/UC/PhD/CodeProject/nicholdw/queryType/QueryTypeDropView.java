package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeDropView extends QueryTypeDrop {
	public QueryTypeDropView() {
		super("Drop View");
	}
}
