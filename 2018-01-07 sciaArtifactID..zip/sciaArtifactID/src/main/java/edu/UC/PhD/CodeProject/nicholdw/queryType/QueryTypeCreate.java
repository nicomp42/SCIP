package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeCreate extends QueryType {
	public QueryTypeCreate(String queryType) {
		super(queryType);
	}
	public QueryTypeCreate() {
		super("Alter");
	}
	
}
