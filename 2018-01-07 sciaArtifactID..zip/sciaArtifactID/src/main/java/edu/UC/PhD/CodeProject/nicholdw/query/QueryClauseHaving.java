package edu.UC.PhD.CodeProject.nicholdw.query;

public class QueryClauseHaving extends QueryClause {
	public QueryClauseHaving() {super ("Having");}
}

