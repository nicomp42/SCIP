package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeAlterView extends QueryTypeAlter {
	public QueryTypeAlterView() {
		super("Alter View");
	}
}
