package edu.UC.PhD.CodeProject.nicholdw.query;

import java.sql.SQLException;

import edu.UC.PhD.CodeProject.nicholdw.Config;
import edu.UC.PhD.CodeProject.nicholdw.Utils;
import edu.UC.PhD.CodeProject.nicholdw.log.Log;
import lib.SQLUtils;

public class QueryUtils {

}
