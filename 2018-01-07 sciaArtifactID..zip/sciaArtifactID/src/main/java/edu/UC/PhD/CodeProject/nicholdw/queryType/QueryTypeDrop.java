package edu.UC.PhD.CodeProject.nicholdw.queryType;

public  class QueryTypeDrop extends QueryType {
	public QueryTypeDrop(String queryType) {
		super(queryType);
	}
	public QueryTypeDrop() {
		super("DROP");
	}
}
