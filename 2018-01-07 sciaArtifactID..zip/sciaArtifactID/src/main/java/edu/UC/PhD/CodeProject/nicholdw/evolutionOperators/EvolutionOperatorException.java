package edu.UC.PhD.CodeProject.nicholdw.evolutionOperators;

public class EvolutionOperatorException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8845827445062226693L;

	public EvolutionOperatorException(String description) {
		super(description);
	}
}
