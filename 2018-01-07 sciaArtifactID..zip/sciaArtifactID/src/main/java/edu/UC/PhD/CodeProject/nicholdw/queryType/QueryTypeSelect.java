package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeSelect extends QueryType {
	public QueryTypeSelect() {
		super("Select");
	}

}
