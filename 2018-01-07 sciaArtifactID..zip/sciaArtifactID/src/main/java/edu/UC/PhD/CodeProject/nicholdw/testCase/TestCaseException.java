package edu.UC.PhD.CodeProject.nicholdw.testCase;

public class TestCaseException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4791823340000937981L;

	public TestCaseException(String message) {
		super(message);
	}
}
