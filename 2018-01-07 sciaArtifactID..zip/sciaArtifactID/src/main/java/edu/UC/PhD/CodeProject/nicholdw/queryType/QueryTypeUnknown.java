package edu.UC.PhD.CodeProject.nicholdw.queryType;

/**
 * A query that changes the structure of a table
 * @author nicomp
 */
public class QueryTypeUnknown extends QueryType {
	public QueryTypeUnknown() {
		super("Unknown");
	}

}
