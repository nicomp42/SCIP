package edu.UC.PhD.CodeProject.nicholdw.query;

public class QueryClauseSelect extends QueryClause {

	public QueryClauseSelect() {super ("Select");}

}
