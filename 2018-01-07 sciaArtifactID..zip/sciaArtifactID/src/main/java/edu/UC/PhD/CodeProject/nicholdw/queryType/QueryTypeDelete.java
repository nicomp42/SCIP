package edu.UC.PhD.CodeProject.nicholdw.queryType;

public class QueryTypeDelete extends QueryType {
	public QueryTypeDelete() {
		super("DELETE");
	}
}
