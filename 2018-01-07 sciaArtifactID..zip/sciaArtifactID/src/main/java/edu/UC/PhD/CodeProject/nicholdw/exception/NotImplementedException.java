package edu.UC.PhD.CodeProject.nicholdw.exception;

public class NotImplementedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public NotImplementedException(String message) {
		super(message);
	}

}
