package stax;
import javax.xml.parsers.SAXParser;
public class StaxPractice {

	public static void main(String[] args) {


	}

}
