CALL `fullcoveragetestcase`.`CreateAll`();
