create schema FullCoveragetestcase;
